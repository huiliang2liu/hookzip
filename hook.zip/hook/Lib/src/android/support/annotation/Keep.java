package android.support.annotation;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.CLASS)
@Target({java.lang.annotation.ElementType.PACKAGE, java.lang.annotation.ElementType.TYPE, java.lang.annotation.ElementType.ANNOTATION_TYPE, java.lang.annotation.ElementType.CONSTRUCTOR, java.lang.annotation.ElementType.METHOD, java.lang.annotation.ElementType.FIELD})
public @interface Keep
{
}

/* Location:           E:\AndroidSupportLibrary-master\AndroidSupportLibrary-master\AndroidSupportLibrary\libs\android-support-v4.jar
 * Qualified Name:     android.support.annotation.Keep
 * JD-Core Version:    0.6.2
 */