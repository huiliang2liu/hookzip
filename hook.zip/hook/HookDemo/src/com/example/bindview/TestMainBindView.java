package com.example.bindview;

import android.app.Activity;
import android.content.Intent;
import android.widget.TextView;

import com.xh.annotation.ViewAnnotation;
import com.xh.interf.AbstractBindView;
import com.xh.util.XhLog;

/**
 * HookDemo com.example.bindview 2018 2018-5-10 上午10:10:56 instructions：
 * author:liuhuiliang email:825378291@qq.com
 **/

public class TestMainBindView extends AbstractBindView {
	private final static String TAG = "TestMainBindView";
	@ViewAnnotation(id = 0x7f070000, clickMethodName = "clickMethod")
	TextView textView;
	private Activity mActivity;

	private void clickMethod() {
		final Intent intent = new Intent();
		intent.setClassName(mActivity, "com.xh.test.Test2Activity");
		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		mActivity.startActivity(intent);
	}

	private void bindActivity(Activity activity) {
		XhLog.e(TAG, "绑定activity");
		mActivity = activity;
	}

	@Override
	public Object getClickReceiver() {
		// TODO Auto-generated method stub
		return this;
	}

	@Override
	public void bindContent() {
		// TODO Auto-generated method stub
		XhLog.e(TAG, "设置内容");
		textView.setText("获取到插件包中的控件了");
	}

}
