package com.example.bindview;

import android.widget.TextView;

import com.xh.annotation.ViewAnnotation;
import com.xh.interf.AbstractBindView;

/**
 * HookDemo com.example.bindview
 * 2018 2018-5-11 下午7:14:24
 * instructions：
 * author:liuhuiliang  email:825378291@qq.com
 **/

public class Test2BindView extends AbstractBindView {
	@ViewAnnotation(id=0x7f070001)
    TextView textView;
	@Override
	public Object getClickReceiver() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void bindContent() {
		// TODO Auto-generated method stub
		textView.setText("第二个activity被绑定");
	}

}
