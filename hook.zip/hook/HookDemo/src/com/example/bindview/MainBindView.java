package com.example.bindview;

import android.app.Activity;
import android.content.Intent;
import android.widget.TextView;

import com.example.hookdemo.R;
import com.xh.annotation.ViewAnnotation;
import com.xh.interf.AbstractBindView;
import com.xh.reflect.MethodManager;
import com.xh.util.XhLog;

/**
 * HookFrame com.xh.bind.view 2018 2018-5-8 下午6:48:28 instructions：
 * author:liuhuiliang email:825378291@qq.com
 **/

public class MainBindView extends AbstractBindView {
	private final static String TAG = "MainBindView";
	@ViewAnnotation(id = R.id.bind_view_text1, clickMethodName = "text1click")
	private TextView bind_view_text1;
	@ViewAnnotation(id = R.id.bind_view_text2, clickMethodName = "text2click")
	private TextView bind_view_text2;
	@ViewAnnotation(id = R.id.bind_view_text3, clickMethodName = "text3click")
	private TextView bind_view_text3;
	@ViewAnnotation(id = R.id.bind_view_text4, clickMethodName = "text4click")
	private TextView bind_view_text4;
	private Activity mActivity;

	public void setContext(Activity activity) {
		// TODO Auto-generated method stub
		XhLog.e(TAG, "setContext");
		mActivity = activity;
	}

	@Override
	public Object getClickReceiver() {
		// TODO Auto-generated method stub
		return this;
	}

	private void text1click() {
		XhLog.e(TAG, "text1click");
		// final Intent intent = mActivity.getPackageManager()
		// .getLaunchIntentForPackage(mActivity.getPackageName());
		// intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		// mActivity.startActivity(intent);
		Intent intent = new Intent();
		intent.setClassName(mActivity, "com.tvblackAD.demo.MainActivity");
		mActivity.startActivity(intent);
		// Intent intent = new Intent();
		// intent.setClassName(mActivity,
		// "com.example.hookdemo.CircularMainActivity");
		// mActivity.startActivity(intent);
		// mActivity.overridePendingTransition(R.anim.anim_in, R.anim.anim_out);
	}

	private void text2click() {
		Intent intent = new Intent();
		intent.setClassName(mActivity, "com.xh.test.MainActivity");
		mActivity.startActivity(intent);
	}

	private void text3click() {
		try {
			Class textjava = Class.forName("com.example.dextext.TextJava");
			XhLog.e(TAG,
					""
							+ MethodManager.invoke(MethodManager.method(
									textjava, "add", new Class[] { int.class,
											int.class }), null, new Object[] {
									2, 3 }));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	private void text4click() {
		try {
			Class textjava = Class.forName("com.example.jartext.TestJava");
			XhLog.e(TAG,
					""
							+ MethodManager.invoke(MethodManager.method(
									textjava, "multiplication", new Class[] { int.class,
											int.class }), null, new Object[] {
									2, 3 }));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	@Override
	public void bindContent() {
		// TODO Auto-generated method stub
		bind_view_text1.setText("bind_view_text1");
		bind_view_text2.setText("bind_view_text2");
		bind_view_text3.setText("bind_view_text3");
		bind_view_text4.setText("bind_view_text4");
	}

}
