package com.example.hookdemo;

import java.io.File;
import java.io.IOException;
import java.util.Random;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.util.Log;

import com.example.bindview.MainBindView;
import com.xh.util.StreamManage;
import com.xh.util.XhLog;

/**
 * HookFrame com.xh.base 2018 2018-5-3 上午11:29:10 instructions：
 * author:liuhuiliang email:825378291@qq.com
 **/

public class MainActivity extends FragmentActivity {
	private final static String TAG = "MainActivity";
	private MainBindView mMainBindView;
	private FragmentManager mFragmentManager;

	private void bindView(MainBindView mainBindView) {
		XhLog.e(TAG, "bindView");
		mMainBindView = mainBindView;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		int a = new Random(100).nextInt();
		final MyApplication application = (MyApplication) getApplication();
		XhLog.e("application create  id="
				+ getResources().getIdentifier("activity", "layout",
						getPackageName()));
		new Thread() {
			public void run() {
				File savaPat = application.sdkOrApkSavePath();
				try {
					File file = StreamManage.inputStream2File(MainActivity.this
							.getAssets().open("demo.apk"), savaPat
							.getAbsolutePath(), "demo.apk");
					File file1 = StreamManage.inputStream2File(MainActivity.this
							.getAssets().open("TvBlackAD_demo.zip"), savaPat
							.getAbsolutePath(), "TvBlackAD_demo.zip");
					File file2 = StreamManage.inputStream2File(MainActivity.this
							.getAssets().open("classes.dex"), savaPat
							.getAbsolutePath(), "classes.dex");
					File file3 = StreamManage.inputStream2File(MainActivity.this
							.getAssets().open("classes.jar"), savaPat
							.getAbsolutePath(), "classes.jar");
					// File file1 = StreamManage.inputStream2File(
					// MainActivity.this.getAssets().open("circular.apk"),
					// savaPat.getAbsolutePath(), "circular.apk");
					if (file != null&&file1!=null&&file2!=null&&file3!=null)
						Log.e("加载资源包", "加载成功");
					application.load();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			};
		}.start();
	}

}
