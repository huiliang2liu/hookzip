package com.example.hookdemo;

import java.io.File;
import java.io.IOException;
import java.lang.Thread.UncaughtExceptionHandler;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Process;

import com.xh.circular.CircularAnim;
import com.xh.hook.ParasActivityXml;
import com.xh.repair.Load;
import com.xh.util.Manager;
import com.xh.util.XhLog;

/**
 * XhApplication com.xh.base 2018/4/13 10:12 instructions： author:liuhuiliang
 * email:825378291@qq.com
 **/

public class MyApplication extends Application implements
		UncaughtExceptionHandler {

	@Override
	public void onCreate() {
		super.onCreate();
		XhLog.setTAG(getPackageName());
		Thread.setDefaultUncaughtExceptionHandler(this);
		XhLog.setIsDebug(true);
		Manager manager = Manager.init();
		CircularAnim.init(700, 500, R.color.colorPrimary);
		try {
			manager.merge(new ParasActivityXml(getAssets().open("activity.xml")));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		XhLog.e("application create  id="
				+ getResources().getIdentifier("activity", "layout",
						getPackageName()));
	}

	/**
	 * 
	 * lhl 2018-1-12 下午5:55:40 说明：加载外挂包，最好在子线程，耗时操作 void
	 */
	public final void load() {
		// TODO Auto-generated method stub
		Load.init(this, sdkOrApkSavePath());
	}

	/**
	 * 
	 * lhl 2018-1-12 下午5:49:31 说明：补丁包保存位置
	 * 
	 * @return Field
	 */
	public final File sdkOrApkSavePath() {
		return getDir("third", Context.MODE_PRIVATE);
	}

	@SuppressWarnings("deprecation")
	@SuppressLint("NewApi")
	@Override
	public void uncaughtException(Thread thread, Throwable ex) {
		// TODO Auto-generated method stub
		ex.printStackTrace();
		System.exit(0);
		Process.killProcess(Process.myPid());
	}

}
