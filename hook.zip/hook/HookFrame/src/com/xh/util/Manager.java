package com.xh.util;

import java.lang.Thread.UncaughtExceptionHandler;

import android.app.Activity;

import com.xh.hook.AMSHook;
import com.xh.hook.ParasActivityXml;
import com.xh.hook.ParasActivityXml.ActivityXml;

/**
 * HookFrame com.xh.util 2018 2018-4-23 上午9:36:12 instructions：
 * author:liuhuiliang email:825378291@qq.com
 **/

public class Manager {
	private static Manager mManager;
	private ParasActivityXml xml;
//	public AMSHook mHook;

	public ParasActivityXml getXml() {
		return xml;
	}

	public static ActivityXml activity2activityXml(Activity activity) {
		if (activity == null)
			return null;
		return activity2activityXml(activity.getClass());
	}

	public static ActivityXml activity2activityXml(Class cls) {
		if (cls == null)
			return null;
		return activity2activityXml(cls.getName());
	}

	public static ActivityXml activity2activityXml(String className) {
		if (mManager != null) {
			ParasActivityXml xml = mManager.getXml();
			if (xml != null) {
				return xml.class2activityXml(className);
			}
		}
		return null;
	}

	public static Manager init() {
		if (mManager == null)
			synchronized (Manager.class) {
				if (mManager == null)
					mManager = new Manager();
			}
		return mManager;
	}

	public static Manager getManager() {
		if (mManager == null)
			throw new RuntimeException("you must be init in application");
		return mManager;
	}

	private Manager() {
		Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(Thread
				.getDefaultUncaughtExceptionHandler()));
		ContentManager.getManager();
//		mHook = 
				AMSHook.init();
		MainfiestManager.mainfiest();
		xml = new ParasActivityXml();
	}

	public Manager merge(ParasActivityXml xml) {
		this.xml.merge(xml);
		return this;
	}

	private class ExceptionHandler implements UncaughtExceptionHandler {
		private UncaughtExceptionHandler mDefaultUncaughtExceptionHandler;

		public ExceptionHandler(
				UncaughtExceptionHandler defaultUncaughtExceptionHandler) {
			// TODO Auto-generated constructor stub
			mDefaultUncaughtExceptionHandler = defaultUncaughtExceptionHandler;
		}

		@Override
		public void uncaughtException(Thread thread, Throwable ex) {
			// TODO Auto-generated method stub
			ex.printStackTrace();
			if (mDefaultUncaughtExceptionHandler != null)
				mDefaultUncaughtExceptionHandler.uncaughtException(thread, ex);
		}

	}
}
