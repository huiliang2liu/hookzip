package com.xh.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;

/**
 * TvBlackAD-eclipse com.tvblack.tv.utils 2018 2018-5-3 下午3:20:47 instructions：
 * author:liuhuiliang email:825378291@qq.com
 **/

public class Mac {
	/**
	 * 获取mac地址
	 * 
	 * @param context
	 * @return
	 */
	public static String getMAC(Context context) {
		return getWireMacAddr(context);
	}

	/*
	 * 获取mac号
	 */
	private static String getWireMacAddr(Context context) {
		try {
			String mac = readLine("/sys/class/net/eth0/address");
			if (!isEmpty(mac))
				return mac;
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			String mac = getMacAddressbus();
			if (!isEmpty(mac))
				return mac;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return getMacAddress();
	}

	private static String getMacAddressbus() {
		String result = "";
		String Mac = "";
		result = callCmd("busybox ifconfig", "HWaddr");

		// 如果返回的result == null，则说明网络不可取
		if (result == null) {
			return "网络出错，请检查网络";
		}

		// 对该行数据进行解析
		// 例如：eth0 Link encap:Ethernet HWaddr 00:16:E8:3E:DF:67
		if (result.length() > 0 && result.contains("HWaddr") == true) {
			Mac = result.substring(result.indexOf("HWaddr") + 6,
					result.length() - 1);
			Log.i("test", "Mac:" + Mac + " Mac.length: " + Mac.length());

			if (Mac.length() > 1) {
				Mac = Mac.replaceAll(" ", "");
				result = "";
				String[] tmp = Mac.split(":");
				for (int i = 0; i < tmp.length; ++i) {
					result += tmp[i];
				}
			}
			Log.i("test", result + " result.length: " + result.length());
		}
		return result;
	}

	private static String callCmd(String cmd, String filter) {
		String result = "";
		String line = "";
		try {
			Process proc = Runtime.getRuntime().exec(cmd);
			InputStreamReader is = new InputStreamReader(proc.getInputStream());
			BufferedReader br = new BufferedReader(is);

			// 执行命令cmd，只取结果中含有filter的这一行
			while ((line = br.readLine()) != null
					&& line.contains(filter) == false) {
				// result += line;
				Log.i("test", "line: " + line);
			}

			result = line;
			Log.i("test", "result: " + result);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	private static String readLine(String filename) throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(filename),
				256);
		try {
			return reader.readLine();
		} finally {
			reader.close();
		}
	}

	@SuppressLint({ "NewApi", "DefaultLocale" })
	public static String getMacAddress() {
		String strMacAddr = null;
		try {
			InetAddress ip = getLocalInetAddress();

			byte[] b = NetworkInterface.getByInetAddress(ip)
					.getHardwareAddress();
			StringBuffer buffer = new StringBuffer();
			for (int i = 0; i < b.length; i++) {
				if (i != 0) {
					buffer.append(':');
				}

				String str = Integer.toHexString(b[i] & 0xFF);
				buffer.append(str.length() == 1 ? 0 + str : str);
			}
			strMacAddr = buffer.toString().toUpperCase();
			if (!isEmpty(strMacAddr)) {
				strMacAddr = strMacAddr.toLowerCase();
				return strMacAddr + "   getMacAddress";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return getMac();
	}

	@SuppressLint("NewApi")
	private static boolean isEmpty(String strMacAddr) {
		// TODO Auto-generated method stub
		return strMacAddr == null || strMacAddr.isEmpty();
	}

	/**
	 * 获取移动设备本地IP
	 * 
	 * @return
	 */
	protected static InetAddress getLocalInetAddress() {
		InetAddress ip = null;
		try {
			// 列举
			Enumeration en_netInterface = NetworkInterface
					.getNetworkInterfaces();
			while (en_netInterface.hasMoreElements()) {// 是否还有元素
				NetworkInterface ni = (NetworkInterface) en_netInterface
						.nextElement();// 得到下一个元素
				Enumeration en_ip = ni.getInetAddresses();// 得到一个ip地址的列举
				while (en_ip.hasMoreElements()) {
					ip = (InetAddress) en_ip.nextElement();
					if (!ip.isLoopbackAddress()
							&& ip.getHostAddress().indexOf(":") == -1)
						break;
					else
						ip = null;
				}

				if (ip != null) {
					break;
				}
			}
		} catch (SocketException e) {

			e.printStackTrace();
		}
		return ip;
	}

	// 获取当前连接网络的网卡的mac地址
	private static String parseByte(byte b) {
		String s = "00" + Integer.toHexString(b) + ":";
		return s.substring(s.length() - 3);
	}

	/**
	 * 获取当前系统连接网络的网卡的mac地址
	 * 
	 * @return
	 */
	@SuppressLint("NewApi")
	public static final String getMac() {
		byte[] mac = null;
		StringBuffer sb = new StringBuffer();
		try {
			Enumeration<NetworkInterface> netInterfaces = NetworkInterface
					.getNetworkInterfaces();
			while (netInterfaces.hasMoreElements()) {
				NetworkInterface ni = netInterfaces.nextElement();
				Enumeration<InetAddress> address = ni.getInetAddresses();

				while (address.hasMoreElements()) {
					InetAddress ip = address.nextElement();
					if (ip.isAnyLocalAddress() || !(ip instanceof Inet4Address)
							|| ip.isLoopbackAddress())
						continue;
					if (ip.isSiteLocalAddress())
						mac = ni.getHardwareAddress();
					else if (!ip.isLinkLocalAddress()) {
						mac = ni.getHardwareAddress();
						break;
					}
				}
			}
		} catch (SocketException e) {
			e.printStackTrace();
		}

		if (mac != null) {
			for (int i = 0; i < mac.length; i++) {
				sb.append(parseByte(mac[i]));
			}
			String mac1 = sb.substring(0, sb.length() - 1);
			mac1 = mac1.toLowerCase();
			return mac1;
		} else {
			return "";
		}
	}

}
