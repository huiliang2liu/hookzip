package com.xh.hook;

import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import android.graphics.Color;

import com.xh.string.StringUtil;
import com.xh.util.XhLog;

/**
 * HookFrame com.xh.hook 2018 2018-4-23 下午4:30:22 instructions：
 * author:liuhuiliang email:825378291@qq.com
 **/

public final class ParasActivityXml {
	private final static String TAG = "ParasActivityXml";
	private List<ActivityXml> activities;
	public List<ApplicationXml> applications;

	public ParasActivityXml() {
		// TODO Auto-generated constructor stub
		activities = new ArrayList<>();
		applications=new ArrayList<ParasActivityXml.ApplicationXml>();
	}

	public ParasActivityXml(InputStream is) {
		// TODO Auto-generated constructor stub
		try {
			activities = new ArrayList<>();
			applications = new ArrayList<>();
			DocumentBuilder documentBuilder = DocumentBuilderFactory
					.newInstance().newDocumentBuilder();
			Document document = documentBuilder.parse(is);
			NodeList list = document.getChildNodes();
			Node node = list.item(0);
			list = node.getChildNodes();
			for (int i = 0; i < list.getLength(); i++) {
				node = list.item(i);
				if ("activity".equals(node.getNodeName())) {
					ActivityXml activity = null;
					String nodeName = node.getNodeName();
					if ("activity".equals(nodeName)) {
						activity = parasActivity(node);
					}
					if (activity == null)
						continue;
					activities.add(activity);
				} else if ("application".equals(node.getNodeName())) {
					ApplicationXml application = parasApplication(node);
					if (application != null)
						applications.add(application);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	private ApplicationXml parasApplication(Node node) {
		// TODO Auto-generated method stub
		NamedNodeMap map = node.getAttributes();
		if (map == null || map.getLength() <= 0)
			return null;
		// <application class="com.tvblackAD.demo.DemoApplication"
		// package="com.tvblackAD.demo">
		String className = parasAtt(map, "class");
		String packageName = parasAtt(map, "package");
		if (StringUtil.isEmpty(className) || StringUtil.isEmpty(packageName))
			return null;
		XhLog.e(TAG, "有application");
		ApplicationXml application=new ApplicationXml();
		application.application=className;
		application.packageName=packageName;
		return application;
	}

	private Title parasTitle(Node valueNode) {
		// TODO Auto-generated method stub
		NamedNodeMap map = valueNode.getAttributes();
		if (map == null || map.getLength() <= 0)
			return null;
		Title title = new Title();
		boolean is = Boolean.valueOf(parasAtt(map, "is"));
		title.is = is;
		if (is) {
			title.layoutName = parasAtt(map, "layoutName");
			title.size = parasAtt(map, "size");
			title.title = parasAtt(map, "title");
			title.color = StringUtil.color(parasAtt(map, "color"));
			title.textColor = StringUtil.color(parasAtt(map, "textColor"));
			title.textSize = parasAtt(map, "textSize");
		}
		return title;
	}

	private BindView parasBindView(Node valueNode) {
		// TODO Auto-generated method stub
		NamedNodeMap map = valueNode.getAttributes();
		if (map == null || map.getLength() <= 0)
			return null;
		String bindClass = parasAtt(map, "class");
		if (StringUtil.isEmpty(bindClass))
			return null;
		BindView bindView = new BindView();
		bindView.bindName = bindClass;
		bindView.setContentName = parasAtt(map, "setContext");
		return bindView;
	}

	/**
	 * 
	 * 2018 2018-5-9 上午10:00:17 annotation：解析acticity 标签 author：liuhuiliang
	 * email ：825378291@qq.com
	 * 
	 * @param valueNode
	 * @return ActivityXml
	 */
	private ActivityXml parasActivity(Node valueNode) {
		NamedNodeMap map = valueNode.getAttributes();
		if (map.getLength() <= 0)
			return null;
		String activityName = parasAtt(map, "class");
		if (StringUtil.isEmpty(activityName)) {
			XhLog.e(TAG, "没有启动的activity");
			return null;
		}
		ActivityXml activityXml = new ActivityXml();
		activityXml.activityName = activityName;
		activityXml.packageName = parasAtt(map, "package");
		activityXml.layoutName = parasAtt(map, "layout");
		activityXml.bootMode = parasAtt(map, "bootMode");
		activityXml.bindMethodName = parasAtt(map, "bindMethod");
		Integer color = StringUtil.color(parasAtt(map, "color"));
		if (color != null)
			activityXml.color = color;
		NodeList nodeList = valueNode.getChildNodes();
		if (nodeList != null && nodeList.getLength() > 0)
			for (int i = 0; i < nodeList.getLength(); i++) {
				Node node = nodeList.item(i);
				if ("enters".equals(node.getNodeName())) {
					activityXml.enters = new ArrayList<>();
					NodeList enters = node.getChildNodes();
					for (int k = 0; k < enters.getLength(); k++) {
						Node enter = enters.item(k);
						if ("enter".equals(enter.getNodeName())) {
							enter.getTextContent();
							String enterValue = enter.getTextContent().trim();
							activityXml.enters.add(StringUtil
									.string2int(enterValue));
						}
					}
				} else if ("exits".equals(node.getNodeName())) {
					activityXml.exits = new ArrayList<>();
					NodeList exits = node.getChildNodes();
					for (int k = 0; k < exits.getLength(); k++) {
						Node enter = exits.item(k);
						if ("exit".equals(enter.getNodeName())) {
							String exitValue = enter.getTextContent().trim();
							activityXml.exits.add(StringUtil
									.string2int(exitValue));
						}
					}
				} else if ("bindView".equals(node.getNodeName())) {
					activityXml.bindView = parasBindView(node);
					;
				} else if ("title".equals(node.getNodeName())) {
					activityXml.title = parasTitle(node);
				}
			}
		return activityXml;
	}

	private String parasAtt(NamedNodeMap map, String attName) {
		Node node = map.getNamedItem(attName);
		if (node == null)
			return null;
		return node.getTextContent();
	}

	public void merge(ParasActivityXml xml) {
		if (xml == null)
			return;
			activities.addAll(xml.activities);
			applications.addAll(xml.applications);
	}

	public String class2packageName(Class cl) {
		if (cl == null)
			return null;
		ActivityXml activity = class2activityXml(cl);
		if (activity == null)
			return null;
		return activity.packageName;
	}

	public ActivityXml class2activityXml(String className) {
		if (!StringUtil.isEmpty(className)) {
			for (int i = 0; i < activities.size(); i++) {
				ActivityXml activity = activities.get(i);
				if (className.equals(activity.activityName))
					return activity;
			}
		}
		return null;
	}

	public ActivityXml class2activityXml(Class className) {
		return class2activityXml(className.getName());
	}

	public class ApplicationXml {
		public String application;
		public String packageName;
	}

	public class ActivityXml {
		public String activityName;
		public String packageName;
		public String bootMode;
		public String layoutName;
		public BindView bindView;
		public Method bindMethod;
		public String bindMethodName;
		public int layoutId = -1;
		public List<Integer> enters = null;
		public List<Integer> exits = null;
		public Integer color = Color.BLACK;
		public Title title;

		@Override
		public boolean equals(Object o) {
			// TODO Auto-generated method stub
			if (o == null || StringUtil.isEmpty(activityName))
				return false;
			if (!o.getClass().equals(ActivityXml.class))
				return false;
			ActivityXml activity = (ActivityXml) o;
			return activityName.equals(activity.activityName);
		}
	}

	public class Title {
		public boolean is = false;
		public String layoutName;
		public String size;
		public String title;
		public String textSize;
		public Integer textColor;
		public Integer color;

	}

	public class BindView {
		public Class bindClass;
		public Method setContent;
		public String bindName;
		public String setContentName;
	}
}
