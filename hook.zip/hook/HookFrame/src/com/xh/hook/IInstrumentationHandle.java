package com.xh.hook;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.app.Instrumentation;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Color;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

import com.xh.annotation.ViewAnnotationParse;
import com.xh.hook.ParasActivityXml.ActivityXml;
import com.xh.hook.ParasActivityXml.ApplicationXml;
import com.xh.hook.ParasActivityXml.BindView;
import com.xh.hook.ParasActivityXml.Title;
import com.xh.interf.AbstractBindView;
import com.xh.interf.IClick;
import com.xh.interf.IViewAnnotation;
import com.xh.reflect.ClassManager;
import com.xh.reflect.FieldManager;
import com.xh.reflect.MethodManager;
import com.xh.repair.AMRP;
import com.xh.repair.Load;
import com.xh.string.StringUtil;
import com.xh.util.ContentManager;
import com.xh.util.Manager;
import com.xh.util.ResourceRecovery;
import com.xh.util.ViewAnnotationImpl;
import com.xh.util.XhLog;

/**
 * 2018/4/16 11:52 instructions： author:liuhuiliang email:825378291@qq.com
 **/

public class IInstrumentationHandle implements InvocationHandler {
	private final static String TAG = "IInstrumentationHandle";
	private Instrumentation mInstrumentation;
	private static Field mResourcesField;
	private static Field mThemeField;
	private static Field mResourcesField1;
	private static Field mThemeField1;
	private static Field mPackageInfo;
	// private Application mApplication;
	private static Field mApplication;
	// final @NonNull LoadedApk mPackageInfo;
	// private Application mApplication;
	private static Field LoadedApkmApplication;
	private static Object loadedApk;
	private float density = -1;
	private float scaledDensity;
	private Map<String, Application> mApplicationMap;
	private static Field mBase;
	static {
		Class<?> contextImplClass = ClassManager
				.forName("android.app.ContextImpl");
		mResourcesField = FieldManager.field(contextImplClass, "mResources");
		mThemeField = FieldManager.field(contextImplClass, "mTheme");
		mResourcesField1 = FieldManager.field(ContextThemeWrapper.class,
				"mResources");
		mThemeField1 = FieldManager.field(ContextThemeWrapper.class, "mTheme");
		mPackageInfo = FieldManager.field(contextImplClass, "mPackageInfo");
		mApplication = FieldManager.field(Activity.class, "mApplication");
		Class<?> LoadedApk = ClassManager.forName("android.app.LoadedApk");
		LoadedApkmApplication = FieldManager.field(LoadedApk, "mApplication");
		mBase = FieldManager.field(ContextWrapper.class, "mBase");
	}

	public IInstrumentationHandle(Instrumentation instrumentation) {
		mInstrumentation = instrumentation;
	}

	@Override
	public Object invoke(Object proxy, Method method, Object[] args)
			throws Throwable {
		Class<?>[] types = method.getParameterTypes();
		String methodName = method.getName();
		XhLog.i(TAG, methodName);
		Method mMethod = MethodManager.method(Instrumentation.class,
				methodName, types);
		if (methodName.equals("newActivity")) {
			XhLog.i(TAG, "newActivity");
			Activity mActivity = (Activity) mMethod.invoke(mInstrumentation,
					args);
			ContentManager contentManager = ContentManager.getManager();
			Field mActivityField = FieldManager.field(ContentManager.class,
					"mActivity");
			mActivityField.set(contentManager, mActivity);
			ParasActivityXml xml = Manager.getManager().getXml();
			XhLog.i(TAG, "匹配清单文件中的Activity=" + mActivity.getClass());
			String packageName = xml.class2packageName(mActivity.getClass());
			XhLog.i(TAG, "获取到包名=" + packageName);
			Load load = Load.getLoad();
			if (mApplicationMap == null) {
				Application application = ContentManager.getManager()
						.getApplication();
				List<ApplicationXml> applications = Manager.getManager()
						.getXml().applications;
				if (applications != null && applications.size() > 0)
					for (int i = 0; i < applications.size(); i++) {
						ApplicationXml applicationXml = applications.get(i);
						XhLog.e(TAG, "applicationName="
								+ applicationXml.application);
						Class cl = ClassManager
								.forName(applicationXml.application);
						Application mApplication = (Application) ClassManager
								.new_object(cl);
						XhLog.e(TAG, "创建applications");
						if (mApplication != null) {
							XhLog.e(TAG, "创建application成功");
							FieldManager.set_field(
									mApplication,
									mBase,
									new PackageContext(application
											.getBaseContext(),
											load != null ? load
													.package2amrp(packageName)
													: null, null));
							if (mApplicationMap == null)
								mApplicationMap = new HashMap<>();
							mApplicationMap.put(applicationXml.packageName,
									mApplication);
						} else
							XhLog.e(TAG, "创建application 失败");
					}
			}
			if (!StringUtil.isEmpty(packageName) && load != null) {
				if (mActivity.getBaseContext() == null)
					XhLog.e(TAG, "mBase is null");
				setResources(mActivity, load.package2amrp(packageName));
				setApplication(mActivity, packageName);
			}
			return mActivity;
		} else if (methodName.equals("callActivityOnCreate")) {
			Activity mActivity = (Activity) args[0];
			mActivity
					.getWindow()
					.setSoftInputMode(
							WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
									| WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
			ActivityXml activityXml = Manager.activity2activityXml(mActivity);
			if (activityXml != null) {
				setBase(mActivity, activityXml);
				XhLog.e(TAG, "package=" + mActivity.getPackageName()
						+ " xmlPackage=" + activityXml.packageName);
				if (activityXml.layoutId < 0) {
					String layoutName = activityXml.layoutName;
					XhLog.i(TAG, "layoutName=" + layoutName + "   packageName="
							+ activityXml.packageName);
					if (!StringUtil.isEmpty(layoutName)) {
						activityXml.layoutId = Load.layout(
								layoutName,
								mActivity.getResources(),
								activityXml.packageName == null ? mActivity
										.getPackageName()
										: activityXml.packageName);
					}
				}
				XhLog.i(TAG, "id=" + activityXml.layoutId);
				if (activityXml.layoutId > 0) {
					setContentView(mActivity, activityXml);
					bindView(mActivity, activityXml);
				}
			}

		} else if (methodName.equals("callActivityOnPause")) {
			setAnim((Activity) args[0]);
			ContentManager contentManager = ContentManager.getManager();
			Field mActivityField = FieldManager.field(ContentManager.class,
					"mActivity");
			mActivityField.set(contentManager, null);
		} else if (methodName.equals("callActivityOnDestroy")) {
			setNull(args[0]);
		} else if ("start".equals(methodName)) {
			XhLog.i(TAG, "start");

		} else if ("callActivityOnResume".equals(methodName)) {
			Activity mActivity = (Activity) args[0];
			setColor(mActivity);
			ActivityXml activityXml = Manager.activity2activityXml(mActivity);
			if (activityXml != null && activityXml.layoutId < 0
					&& activityXml.bindView != null) {
				bindView(mActivity, activityXml);
			}
			return mMethod.invoke(mInstrumentation, args);
		} else if ("callApplicationOnCreate".equals(methodName)) {

		}
		return mMethod.invoke(mInstrumentation, args);
	}

	private void setBase(Activity mActivity, ActivityXml activityXml) {
		// TODO Auto-generated method stub
		if (mApplicationMap != null)
			FieldManager.set_field(FieldManager.get_field(
					mActivity.getBaseContext(), mPackageInfo),
					LoadedApkmApplication, mApplicationMap
							.get(activityXml.packageName));
		Load load = Load.getLoad();
		if (load != null) {
			AMRP amrp = load.package2amrp(activityXml.packageName);
			FieldManager.set_field(
					mActivity,
					mBase,
					new PackageContext(mActivity.getBaseContext(), amrp,
							mApplicationMap != null ? mApplicationMap
									.get(activityXml.packageName) : null));
			// FieldManager.set_field(mActivity.getBaseContext(), mThemeField,
			// amrp.mTheme);
		}
	}

	private void setApplication(Activity mActivity, String packageName) {
		// TODO Auto-generated method stub
		if (mApplicationMap != null) {
			XhLog.e(TAG, "设置application");
			FieldManager.set_field(mActivity, mApplication,
					mApplicationMap.get(packageName));

		}
	}

	private void bindView(Activity mActivity, ActivityXml activityXml) {
		// TODO Auto-generated method stub
		BindView bindView = activityXml.bindView;
		if (bindView != null) {
			if (bindView.bindClass == null)
				bindView.bindClass = ClassManager.forName(bindView.bindName);
			Class<?> cls = bindView.bindClass;
			if (cls != null) {
				if (AbstractBindView.class.isAssignableFrom(cls)) {
					IClick click = (IClick) ClassManager.new_object(cls);
					if (click != null) {
						if (bindView.setContent == null)
							bindView.setContent = MethodManager.method(
									bindView.bindClass,
									bindView.setContentName,
									new Class[] { Activity.class });
						MethodManager.invoke(bindView.setContent, click,
								new Object[] { mActivity });
						IViewAnnotation viewAnnotation = new ViewAnnotationImpl(
								mActivity.findViewById(android.R.id.content),
								click);
						ViewAnnotationParse.parse(click.getClickReceiver(),
								viewAnnotation, click);
						click.bindContent();
						click.setViewAnnotation(viewAnnotation);
						if (activityXml.bindMethod == null) {
							activityXml.bindMethod = MethodManager.method(
									mActivity.getClass(),
									activityXml.bindMethodName,
									new Class[] { cls });
						}
						MethodManager.invoke(activityXml.bindMethod, mActivity,
								new Object[] { click });
					}
				}
			} else {
				XhLog.i(TAG, "bindView erro");
			}
		}
	}

	private void setContentView(Activity mActivity, ActivityXml activityXml) {
		// TODO Auto-generated method stub
		View groupView = LayoutInflater.from(mActivity).inflate(
				activityXml.layoutId, null);
		Title title = activityXml.title;
		if (title != null) {
			View titileView = title(mActivity, title);
			if (titileView != null) {
				mActivity.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
				LinearLayout layout = new LinearLayout(mActivity);
				layout.setOrientation(LinearLayout.VERTICAL);
				LayoutParams params = new LayoutParams(
						LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
				layout.setLayoutParams(params);
				layout.addView(titileView);
				layout.addView(groupView);
				groupView = layout;
			}
		}
		mActivity.setContentView(groupView);
	}

	@SuppressLint("NewApi")
	private View title(Activity mActivity, Title title) {
		// TODO Auto-generated method stub
		if (!title.is) {
			return null;
		} else {
			int layoutId = -1;
			layoutId = Load.layout(title.layoutName, mActivity.getResources(),
					mActivity.getPackageName());
			View titleView = null;
			if (layoutId > 0) {
				titleView = LayoutInflater.from(mActivity).inflate(layoutId,
						null);
			} else {
				String titleText = "";
				titleText = title.title;
				int color = Color.BLACK;
				if (title.color != null)
					color = title.color;
				TextView textView = new TextView(mActivity);
				textView.setGravity(Gravity.CENTER);
				int textColor = Color.WHITE;
				if (title.textColor != null)
					textColor = title.textColor;
				String textSize = title.textSize;
				if (StringUtil.isEmpty(textSize))
					textSize = "16dip";
				textView.setTextColor(textColor);
				textView.setTextSize(topx(textSize));
				textView.setText(titleText);
				textView.setBackgroundColor(color);
				titleView = textView;
			}
			if (density < 0) {
				DisplayMetrics dm = new DisplayMetrics();
				mActivity.getWindowManager().getDefaultDisplay().getMetrics(dm);
				density = dm.density;
				scaledDensity = dm.scaledDensity;
			}
			String size = title.size;
			if (StringUtil.isEmpty(size))
				size = "26dip";
			LayoutParams titleViewLP = new LayoutParams(
					LayoutParams.MATCH_PARENT, topx(size));
			titleView.setLayoutParams(titleViewLP);
			return titleView;
		}
	}

	private int topx(String size) {
		if (size.endsWith("dip"))
			return (int) (density
					* Float.valueOf(size.substring(0, size.length() - 3)) + 0.5);
		if (size.endsWith("dp"))
			return (int) (density
					* Float.valueOf(size.substring(0, size.length() - 2)) + 0.5);
		if (size.endsWith("sp"))
			return (int) (scaledDensity
					* Float.valueOf(size.substring(0, size.length() - 2)) + 0.5);
		return (int) Float.valueOf(size).floatValue();

	}

	private void setAnim(Activity activity) {
		ActivityXml activityXml = Manager.activity2activityXml(activity);
		if (activityXml != null) {
			List<Integer> enters = activityXml.enters;
			List<Integer> exits = activityXml.exits;
			if (enters != null && enters.size() > 0 && exits != null
					&& exits.size() > 0) {
				int entersSize = enters.size();
				int exitsSize = exits.size();
				int index = entersSize > exitsSize ? exitsSize : entersSize;
				XhLog.i(TAG, "设置退出动画");
				for (int i = 0; i < index; i++) {
					Integer enter = enters.get(i);
					Integer exit = exits.get(i);
					if (enter == null || exit == null)
						continue;
					activity.overridePendingTransition(enter, exit);
				}
			}
		}
	}

	/** * 设置状态栏颜色 * * @param activity 需要设置的activity * @param color 状态栏颜色值 */
	@SuppressLint("NewApi")
	private void setColor(Activity activity) {
		// TODO Auto-generated method stub
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
			// 设置状态栏透明
			ActivityXml androidXml = Manager.activity2activityXml(activity);
			if (androidXml == null) {
				XhLog.e(TAG, "设置头部颜色失败");
				return;
			}
			XhLog.e(TAG, "设置头部颜色成功");
			int color = -1;
			color = androidXml.color;
			activity.getWindow().addFlags(
					WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			// 生成一个状态栏大小的矩形

			int resourceId = activity.getResources().getIdentifier(
					"status_bar_height", "dimen", "android");
			int statusBarHeight = activity.getResources()
					.getDimensionPixelSize(resourceId);
			// 绘制一个和状态栏一样高的矩形
			View statusView = new View(activity);
			LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
					ViewGroup.LayoutParams.MATCH_PARENT, statusBarHeight);
			statusView.setLayoutParams(params);
			statusView.setBackgroundColor(color);
			// 添加 statusView 到布局中
			ViewGroup decorView = (ViewGroup) activity.getWindow()
					.getDecorView();
			decorView.addView(statusView);
			// 设置根布局的参数
			ViewGroup rootView = (ViewGroup) ((ViewGroup) activity
					.findViewById(android.R.id.content)).getChildAt(0);
			rootView.setFitsSystemWindows(true);
			rootView.setClipToPadding(true);
		}

	}

	private void setResources(Activity activity, AMRP amrp) {
		if (amrp == null) {
			XhLog.i(TAG, "没有对应的资源");
			return;
		}
		// FieldManager.set_field(activity.getBaseContext(), mResourcesField,
		// amrp.resources);
		// FieldManager.set_field(activity.getBaseContext(), mThemeField,
		// amrp.mTheme);
		FieldManager.set_field(activity, mResourcesField1, amrp.resources);
		FieldManager.set_field(activity, mThemeField1, amrp.mTheme);
		XhLog.i(TAG, "设置资源加载成功");
	}

	/**
	 * 2018/4/16 12:24 annotation：将变量中的字段制空 author：liuhuiliang email
	 * ：825378291@qq.com
	 * 
	 * 
	 */
	private void setNull(Object object) {
		ResourceRecovery.gc(object);
	}
}
