package com.xh.repair;

import java.io.File;
import java.io.FilenameFilter;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import com.xh.reflect.MethodManager;
import com.xh.util.Manager;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Resources;
import dalvik.system.BaseDexClassLoader;
import dalvik.system.PathClassLoader;

/**
 * HookFrame com.xh.repair 2018 2018-5-10 下午5:52:35 instructions：
 * author:liuhuiliang email:825378291@qq.com
 **/

public class LoadDex {
	private final static String OPT = "opt";
	private final static String OPT_OS = "opt_os";
	private BaseDexClassLoader baseDexClassLoader;
	public List<AMRP> aList;

	public LoadDex(File filePath, Context context) {
		// TODO Auto-generated constructor stub
		if (!filePath.exists() || !filePath.isDirectory())
			throw new RuntimeException("file is not exist or directory");
		if (context == null)
			throw new RuntimeException("context is null");
		File optimizedDirectory = new File(filePath, OPT);
		if (!optimizedDirectory.exists())
			optimizedDirectory.mkdirs();
		File librarySearchPath = new File(filePath, OPT_OS);
		if (!librarySearchPath.exists())
			librarySearchPath.mkdirs();
		File[] files = filePath.listFiles(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {
				// TODO Auto-generated method stub
				return name.endsWith(".dex") || name.endsWith(".zip")
						|| name.endsWith(".apk") || name.endsWith(".jar");
			}
		});
		StringBuffer dexPath = new StringBuffer();
		aList = new ArrayList<AMRP>();
		for (int i = 0; i < files.length; i++) {
			File file = files[i];
			dexPath.append(file.getAbsolutePath()).append(":");
			if (file.getName().endsWith(".apk")
					|| file.getName().endsWith(".zip")) {
				SoLibManager.getSoLoader().copyPluginSoLib(context,
						file.getAbsolutePath(),
						librarySearchPath.getAbsolutePath());
				try {
					AssetManager assetManager = AssetManager.class
							.newInstance();
					Method addAssetPath = assetManager.getClass().getMethod(
							"addAssetPath", String.class);
					PackageInfo packageInfo = context.getPackageManager()
							.getPackageArchiveInfo(
									file.getAbsolutePath(),
									PackageManager.GET_ACTIVITIES
											| PackageManager.GET_SERVICES
											| PackageManager.GET_META_DATA
											| PackageManager.GET_PERMISSIONS
											| PackageManager.GET_SIGNATURES);
					addAssetPath.invoke(assetManager, file.getAbsolutePath());
					Resources superRes = context.getResources();
					Resources mResources = new Resources(assetManager,
							superRes.getDisplayMetrics(),
							superRes.getConfiguration());
					aList.add(new AMRP(packageInfo, assetManager, mResources));
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
			}
		}
		File[] sos = librarySearchPath.listFiles(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {
				// TODO Auto-generated method stub
				return name.endsWith(".so") && !name.endsWith("liblbs.so");
			}
		});
		baseDexClassLoader = new BaseDexClassLoader(dexPath.substring(0,
				dexPath.length() - 1), optimizedDirectory,
				librarySearchPath.getAbsolutePath(), context.getClassLoader());
//		if (sos != null && sos.length > 0)
//			for (int i = 0; i < sos.length; i++) {
//				try {
//					String name = sos[i].getName();
//					Method loadLibrary = MethodManager.method(Runtime.class,
//							"loadLibrary", new Class[] { String.class,
//									ClassLoader.class });
//					MethodManager.invoke(loadLibrary, Runtime.getRuntime(),
//							new Object[] {
//									name.substring(3, name.length() - 3),
//									baseDexClassLoader });
//				} catch (Exception e) {
//					// TODO: handle exception
//				}
//			}
//		Manager.getManager().mHook.mainThread.setContextClassLoader(baseDexClassLoader);
		inject(baseDexClassLoader, context);
	}

	private static void inject(BaseDexClassLoader classLoader, Context context) {
		try {
			PathClassLoader pathClassLoader = (PathClassLoader) context
					.getClassLoader();
			Object dexElements = combineArray(
					getDexElements(getPathList(pathClassLoader)),
					getDexElements(getPathList(classLoader)));
			Object pathList = getPathList(pathClassLoader);
			setField(pathList, pathList.getClass(), "dexElements", dexElements);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * lhl 2017-12-5 下午2:43:51 说明：获取加载路径列表
	 * 
	 * @param baseDexClassLoader
	 * @return Object
	 */
	private static Object getPathList(Object baseDexClassLoader) {
		try {
			return getField(baseDexClassLoader,
					Class.forName("dalvik.system.BaseDexClassLoader"),
					"pathList");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 
	 * lhl 2017-12-5 下午2:41:49 说明：获取dex列表
	 * 
	 * @param object
	 * @return Object
	 */
	private static Object getDexElements(Object object) {
		try {
			return getField(object, object.getClass(), "dexElements");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 
	 * lhl 2017-12-5 下午2:40:15 说明：获取字段的值
	 * 
	 * @param object
	 * @param cl
	 * @param filedName
	 * @return Object
	 */
	private static Object getField(Object object, Class cl, String filedName) {
		try {
			Field field = cl.getDeclaredField(filedName);
			if (!field.isAccessible())
				field.setAccessible(true);
			return field.get(object);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 
	 * lhl 2017-12-5 下午2:37:57 说明：设置字段值
	 * 
	 * @param object
	 * @param cl
	 * @param fieldName
	 * @param value
	 *            void
	 */
	private static void setField(Object object, Class cl, String fieldName,
			Object value) {
		try {
			Field field = cl.getDeclaredField(fieldName);
			if (!field.isAccessible())
				field.setAccessible(true);
			field.set(object, value);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * lhl 2017-12-5 下午2:35:54 说明：合并数组
	 * 
	 * @param arrayLhs
	 * @param arrayRhs
	 * @return Object
	 */
	private static Object combineArray(Object arrayLhs, Object arrayRhs) {
		Class localClass = arrayLhs.getClass().getComponentType();
		int i = Array.getLength(arrayLhs);
		int j = i + Array.getLength(arrayRhs);
		Object result = Array.newInstance(localClass, j);
		for (int k = 0; k < j; k++) {
			if (k < i)
				Array.set(result, k, Array.get(arrayLhs, k));
			else
				Array.set(result, k, Array.get(arrayRhs, k - i));
		}
		return result;
	}
}
