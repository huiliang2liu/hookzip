package com.xh.interf;

import android.app.Activity;
import android.view.View.OnClickListener;

/**
 * HookFrame com.xh.interf 2018 2018-5-2 上午11:12:54 instructions：
 * author:liuhuiliang email:825378291@qq.com
 **/

public interface IClick extends OnClickListener {
	/**
	 * 
	 * 2018 2018-5-2 上午11:14:08 annotation：点击事件的执行者 author：liuhuiliang email
	 * ：825378291@qq.com
	 * 
	 * @return Object
	 */
	Object getClickReceiver();

	/**
	 * 
	 * 2018 2018-5-2 上午11:16:18 annotation： author：liuhuiliang email
	 * ：825378291@qq.com
	 * 
	 * @param viewAnnotation
	 *            void
	 */
	void setViewAnnotation(IViewAnnotation viewAnnotation);

	/**
	 * 
	 * 2018 2018-5-8 下午7:02:34 annotation：绑定控件以后会回调 author：liuhuiliang email
	 * ：825378291@qq.com void
	 */
	void bindContent();
}
