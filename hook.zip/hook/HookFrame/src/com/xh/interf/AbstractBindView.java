package com.xh.interf;

import android.view.View;

/**
 * HookFrame com.xh.interf 2018 2018-5-8 下午6:22:11 instructions：
 * author:liuhuiliang email:825378291@qq.com
 **/

public abstract class AbstractBindView implements IClick {
	private IViewAnnotation mViewAnnotation;

	@Override
	public final void onClick(View v) {
		// TODO Auto-generated method stub
		mViewAnnotation.invoke(v, getClickReceiver());
	}

	@Override
	public final void setViewAnnotation(IViewAnnotation viewAnnotation) {
		// TODO Auto-generated method stub
		mViewAnnotation = viewAnnotation;
	}

}
